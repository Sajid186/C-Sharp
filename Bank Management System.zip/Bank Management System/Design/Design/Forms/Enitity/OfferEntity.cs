﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Design.Forms.Enitity
{
    class OfferEntity
    {
        public int OfferId { set; get; }
        public string OfferTitle { set; get; }
        public string InterestRate { set; get; }
        public string Description { set; get; }
        public string Approval { set; get; }

    }
}
