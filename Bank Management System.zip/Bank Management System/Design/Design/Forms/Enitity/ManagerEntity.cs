﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Design.Forms.Entity
{
    class ManagerEntity
    {
        public string Name { set; get; }
        public string Username { set; get; }
        public int ManagerId { set; get; }
        public string Password{ set; get; }
    }
}
