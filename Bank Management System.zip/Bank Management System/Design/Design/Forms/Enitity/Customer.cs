﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Design.Forms.Enitity
{
    class Customer
    {
        public string Name { set; get; }
        public int CustomerId { set; get; }
        public string Religion { set; get; }
        public string Gender { set; get; }
        public string Nationality { set; get; }
        public string MaritialStatus { set; get; }
        public string Address { set; get; }
        public string PhoneNumber { set; get; }
        public string AccountNumber { set; get; }
        public string Email { set; get; }
        public string DateOfBirth { set; get; }
    }
}
