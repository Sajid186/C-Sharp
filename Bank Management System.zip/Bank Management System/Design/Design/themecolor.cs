﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Design
{
    public static class themecolor{

        public static List<string> colorList = new List<string>() {
            "#610d15","#4ea7ea","#fc2b2e","#ff18e1","#831822"
        };


    }
}
